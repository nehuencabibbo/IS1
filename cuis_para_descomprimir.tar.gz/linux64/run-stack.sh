#!/bin/bash
vmLiveTyping-Stack/squeak CuisUniversity-6169.image