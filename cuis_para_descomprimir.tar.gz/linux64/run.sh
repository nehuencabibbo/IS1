#!/bin/bash
vmLiveTyping/squeak CuisUniversity-6169.image