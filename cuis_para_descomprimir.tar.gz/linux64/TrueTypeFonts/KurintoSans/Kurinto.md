#Kurinto fonts
From https://www.kurinto.com/ What follows is copied verbatim from the web site:

Open Source

Kurinto is and always will be free. The fonts are available to anyone at no charge, and is licensed under the SIL Open Font License Version 1.1. Kurinto fonts may be used, studied, copied, merged, modified and redistributed.

You may download and embed these fonts in digital documents, use them in commercial projects (including mobile apps), and bundle them (with or without modification) for redistribution under the terms of the SIL Open Font License Version 1.1.