# Measures
This repo has different Measure models implemented in Cuis.
A Measure is the representation of a number and a unit like **10 meters** or **1 dollar**, etc.
