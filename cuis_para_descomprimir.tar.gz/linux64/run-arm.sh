#!/bin/bash
vmLiveTyping-ARM/squeak CuisUniversity-6169.image