#!/bin/bash
vm-jit/squeak CuisUniversity-6169.image